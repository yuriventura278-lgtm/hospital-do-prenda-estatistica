﻿# Instala a Organização Pessoal & Financeira como app no ambiente de trabalho (Windows)
$ErrorActionPreference = 'Stop'
$origem  = Split-Path -Parent $MyInvocation.MyCommand.Path
$destino = Join-Path $env:LOCALAPPDATA 'ControleFinanceiro'
New-Item -ItemType Directory -Force -Path $destino | Out-Null
Copy-Item (Join-Path $origem 'controle_financeiro.html') (Join-Path $destino 'index.html') -Force
Copy-Item (Join-Path $origem 'icone.ico') (Join-Path $destino 'icone.ico') -Force

$candidatos = @(
  "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
  "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
  "$env:LOCALAPPDATA\Microsoft\Edge\Application\msedge.exe",
  "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
  "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
  "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe"
)
$navegador = $candidatos | Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1
if (-not $navegador) {
  Write-Host 'Não encontrei o Microsoft Edge nem o Google Chrome. Instale um deles e tente outra vez.'
  exit 1
}

# Pasta de backup automático: Documentos\Controle Financeiro
$pastaBackup = Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'Controle Financeiro'
New-Item -ItemType Directory -Force -Path $pastaBackup | Out-Null

$url = ([System.Uri](Join-Path $destino 'index.html')).AbsoluteUri
$argumentos = "--app=`"$url`" --window-size=1280,860"
$icone = (Join-Path $destino 'icone.ico') + ',0'
$shell = New-Object -ComObject WScript.Shell
$pastas = @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))
foreach ($pasta in $pastas) {
  Remove-Item (Join-Path $pasta 'Controle Financeiro.lnk') -ErrorAction SilentlyContinue
  $atalho = $shell.CreateShortcut((Join-Path $pasta 'Organização Pessoal e Financeira.lnk'))
  $atalho.TargetPath       = $navegador
  $atalho.Arguments        = $argumentos
  $atalho.IconLocation     = $icone
  $atalho.WorkingDirectory = $destino
  $atalho.Description      = 'Organização Pessoal & Financeira'
  $atalho.Save()
}
Write-Host ''
Write-Host 'Pronto! O atalho "Organização Pessoal e Financeira" foi criado no ambiente de trabalho e no menu Iniciar.'
Write-Host "App instalada em: $destino"
Write-Host "Pasta de backup automático: $pastaBackup"
Write-Host "Na app: Definições > Backup automático > Escolher pasta (escolha esta pasta uma vez)."
Start-Process -FilePath $navegador -ArgumentList $argumentos
