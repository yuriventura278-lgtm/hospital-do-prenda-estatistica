﻿# Remove os atalhos e os ficheiros da app (os dados ficam guardados no navegador)
$destino = Join-Path $env:LOCALAPPDATA 'ControleFinanceiro'
foreach ($pasta in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))) {
  Remove-Item (Join-Path $pasta 'Controle Financeiro.lnk') -ErrorAction SilentlyContinue
}
Remove-Item $destino -Recurse -Force -ErrorAction SilentlyContinue
Write-Host 'Atalhos e ficheiros removidos. Os seus dados continuam guardados no navegador.'
